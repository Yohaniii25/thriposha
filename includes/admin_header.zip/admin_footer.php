<footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6 footer-copyright text-start">
                            <p class="mb-0">Copyright 2024 © Digital Services - Sri Lanka Telecome Services.</p>
                        </div>

                    </div>
                </div>
            </footer>