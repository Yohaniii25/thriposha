<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Thriposha LTD</title>
</head>
<body>
<div class="sidebar">
    <h2>Admin Panel</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="add_news.php">Add News</a></li>
        <li><a href="view_news.php">View News</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>

</body>
</html>